# Experiment 6 — Decimal to Hexadecimal converter

## Terminal session
```
sit-lab2-pc29@sit-lab2-pc29-OptiPlex-3280-AIO:~$ vim exp6_268.l
sit-lab2-pc29@sit-lab2-pc29-OptiPlex-3280-AIO:~$ lex exp6_268.l
sit-lab2-pc29@sit-lab2-pc29-OptiPlex-3280-AIO:~$ cc lex.yy.c -ll
sit-lab2-pc29@sit-lab2-pc29-OptiPlex-3280-AIO:~$ ./a.out
Enter decimal: 7562
Hexadecimal = 1D8A
```
